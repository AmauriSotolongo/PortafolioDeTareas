#!/bin/bash
echo "Hola, Bienvenido!" 
echo "Elige una opcion:"
opcion=""
while true
do
echo "1 -Ejecutar un hola mundo!!!"
echo "2 -Usar el hola mundo con variables" 
echo "3 -Crea un arbol de direcciones"
echo "4 -Salir"
echo "5 -Abrir script variables"
echo "6 -Abrir script arrays"
echo "7 -Abrir script arrays otros usos"
echo "8 -Abrir script aritmeticas"
echo "9 -Abrir script logicas"
echo "10 -Abrir script condicionales"
echo "11 -Abrir script ficheros"
echo "12 -Abrir script case"
echo "13 -Abrir script iteraciones"
echo "14 -Abrir script while"
echo "15 -Abrir script until"
echo "16 -Abrir script select"
echo "17 -Abrir script funciones"
echo "18 -Abrir script librerias"
echo "19 -Abrir script señales"
echo "20 -Abrir script colores"
echo -n "Escribe el numero de la opcion que deseas: "
read opcion 
	case ${opcion} in
	1)
		echo "Opcion 1 ha sido elejida"
		bash actividad1/seis/holamundo.sh
	;;
	2)
	echo "Opcion 2 ha sido elejida"
	bash actividad1/seis/holanombre.sh
	;;
	3)
	echo "Se ha creado el arbol de direcciones"
	bash crear_arbol.sh
	echo "El programa ha sido detenido"
	;;
	4)
	echo "El programa ha sido detenido" 
	break
	;;
	5)
	echo "Abriendo"
	bash variables.sh
	;;
	6)
	echo "Abriendo"
	bash arrays.sh
	;;
	7)
	echo "Abriendo"
	bash arraysotrouso.sh
	;;
	8)
	echo "Abriendo"
	bash aritmeticas.sh
	;;
	9)
	echo "Abriendo"
	bash logicas.sh
	;;
	10)
	echo "Abriendo"
	bash condicionales.sh
	;;
	11)
	echo "Abriendo"
	bash ficheros.sh
	;;
	12)
	echo "Abriendo"
	bash case.sh
	;;
	13)
	echo "Abriendo"
	bash interacciones.sh
	;;
	14)
	echo "Abriendo"
	bash while.sh
	;;
	15)
	echo "Abriendo"
	bash until.sh
	;;
	16)
	echo "Abriendo"
	bash select.sh
	;;
	17)
	echo "Abriendo"
	bash funciones.sh
	;;
	18)
	echo "Abriendo"
	bash librerias.sh
	;;
	19)
	echo "Abriendo"
	bash senales.sh
	;;
	20)
	echo "Abriendo"
	bash colores.sh
	;;
	*) 
	echo "Opcion no valida."
	esac
	
done
